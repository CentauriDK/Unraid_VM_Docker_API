from flask import Flask, request, jsonify
import subprocess
import time
import re
import shutil

app = Flask(__name__)

print("Docker path:", shutil.which("docker"))

def run_command(cmd):
    try:
        output = subprocess.check_output(cmd, stderr=subprocess.STDOUT).decode().strip()
        return True, output
    except subprocess.CalledProcessError as e:
        return False, e.output.decode().strip()

@app.route('/vm/status/<vm_name>', methods=['GET'])
def vm_status(vm_name):
    success, output = run_command(["virsh", "list", "--name", "--state-running"])
    if not success:
        return jsonify({"error": "virsh failed", "details": output}), 500

    if vm_name in output.splitlines():
        return jsonify({"vm": vm_name, "status": "running"})
    else:
        return jsonify({"vm": vm_name, "status": "stopped"})

@app.route('/vm/control', methods=['POST'])
def control_vm():
    data = request.get_json()
    action = data.get("action")
    vm_name = data.get("vm_name")

    if not vm_name or not action:
        return jsonify({"error": "Missing 'vm_name' or 'action'"}), 400

    if action == "start":
        success, output = run_command(["virsh", "start", vm_name])
    elif action == "stop":
        success, output = run_command(["virsh", "shutdown", vm_name])
    elif action == "force-stop":
        success, output = run_command(["virsh", "destroy", vm_name])
    elif action == "restart":
        run_command(["virsh", "shutdown", vm_name])
        time.sleep(2)
        run_command(["virsh", "destroy", vm_name])
        success, output = run_command(["virsh", "start", vm_name])
    else:
        return jsonify({"error": f"Invalid action: {action}"}), 400

    if success:
        return jsonify({"vm": vm_name, "action": action, "result": "success"})
    else:
        return jsonify({"vm": vm_name, "action": action, "result": "error", "details": output}), 500



@app.route('/vm/list', methods=['GET'])
def list_vms():
    success, output = run_command(["virsh", "list", "--all"])
    if not success:
        return jsonify({"error": "Failed to list VMs", "details": output}), 500

    vms = []
    lines = output.splitlines()[2:]  # Skip header lines

    for line in lines:
        # Match: optional ID, name, and state (any number of words at end)
        match = re.match(r'^\s*(?P<id>[-\d]+)\s+(?P<name>.+?)\s{2,}(?P<state>.+)$', line)
        if match:
            vm_id = match.group("id")
            name = match.group("name")
            state = match.group("state")

            vms.append({
                "id": None if vm_id == '-' else vm_id,
                "name": name,
                "state": state
            })

    return jsonify(vms)
    
@app.route('/docker/list', methods=['GET'])
def list_docker():
    success, output = run_command([
        "docker", "ps", "-a", "--format", "{{.Names}}|{{.Status}}"
    ])
    if not success:
        return jsonify({"error": "Failed to list Docker containers"}), 500

    containers = []
    for line in output.splitlines():
        if '|' not in line:
            continue
        name, raw_status = line.split('|', 1)
        name = name.strip()
        raw_status = raw_status.strip()

        # Default values
        status = "stopped"
        uptime = ""

        if raw_status.lower().startswith("up"):
            status = "running"
            uptime = raw_status[3:].strip()  # Extract uptime after 'Up'
        else:
            status = "stopped"

        containers.append({
            "name": name,
            "status": status,
            "uptime": uptime
        })

    return jsonify(containers)
    
    
@app.route('/docker/status/<container_name>', methods=['GET'])
def docker_status(container_name):
    success, output = run_command(["docker", "inspect", "-f", "{{.State.Status}}", container_name])
    if not success:
        return jsonify({"error": f"Could not get status for container '{container_name}'"}), 500

    status = output.lower().strip()
    status_map = {
        "exited": "stopped",
        "created": "stopped",
        "running": "running",
        "paused": "paused",
        "restarting": "restarting",
        "removing": "removing",
        "dead": "error"
    }
    normalized_status = status_map.get(status, status)

    return jsonify({
        "container": container_name,
        "status": normalized_status
    })

@app.route('/docker/control', methods=['POST'])
def control_docker():
    data = request.get_json()
    container_name = data.get("container_name")
    action = data.get("action")

    if not container_name or not action:
        return jsonify({"error": "Missing 'container_name' or 'action'"}), 400

    if action == "start":
        success, output = run_command(["docker", "start", container_name])
    elif action == "stop":
        success, output = run_command(["docker", "stop", container_name])
    else:
        return jsonify({"error": f"Invalid action: {action}"}), 400

    if success:
        return jsonify({"container": container_name, "action": action, "result": "success"})
    else:
        return jsonify({"container": container_name, "action": action, "result": "error", "details": output}), 500
    

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5888)
